package day7.staticMethods;

public class Overlaoding1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	static void addNumbers() {

	}
	static void addNumbers(int num1, int num2) {

	}
	static void addNumbers(double num1, int num2) {

	}
	static void addNumbers(int num1, double num2) {

	}
	
	 void multiNumber() {

	}
	 void multiNumber(int num1, int num2) {

	}
	 void multiNumber(double num1, int num2) {

	}
	 void multiNumber(int num1, double num2) {

	}
}
/*
method declared more then once with diff set of parameters in a class body known as method overloading
1. diff in type of parameter
2. diff in number of parameter
3. diff in position of parameter
*/